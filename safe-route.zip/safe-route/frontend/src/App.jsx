import { useCallback, useEffect, useState } from "react";
import { Users, UserCheck, UserX, Building2, Construction, Route as RouteIcon, Siren, Sun, Moon } from "lucide-react";
import { api } from "./services/api";
import MapView from "./components/MapView";
import { Planner, Visualizer, Simulation, Network } from "./components/Panels";

export default function App() {
  const [sc, setSc] = useState(null);
  const [err, setErr] = useState("");
  const [tab, setTab] = useState("planner");
  const [theme, setTheme] = useState("dark");
  const [toasts, setToasts] = useState([]);
  const [result, setResult] = useState(null);   // { req, dijkstra, bfs, selected }
  const [prev, setPrev] = useState(null);       // previous result (for BEFORE / AFTER)
  const [evac, setEvac] = useState(null);       // last evacuation plan
  const [sim, setSim] = useState(null);
  const [viz, setViz] = useState({ mode: "dijkstra", idx: 0, playing: false });

  const toast = (msg, kind = "info") => {
    const id = Math.random();
    setToasts((t) => [...t, { id, msg, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 5000);
  };
  const load = useCallback(async () => {
    try { setSc(await api.scenario()); setErr(""); } catch (e) { setErr(e.message); }
  }, []);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { document.documentElement.dataset.theme = theme; }, [theme]);

  const steps = (viz.mode === "pq" ? evac?.queue_steps : result?.[viz.mode]?.steps) || [];
  useEffect(() => {
    if (!viz.playing) return;
    const t = setInterval(() => setViz((v) => (v.idx >= steps.length - 1 ? { ...v, playing: false } : { ...v, idx: v.idx + 1 })), 900);
    return () => clearInterval(t);
  }, [viz.playing, steps.length]);

  const calculate = async (req, before = null) => {
    try {
      const [dijkstra, bfs] = await Promise.all([api.route("dijkstra", req), api.route("bfs", req)]);
      const selected = req.algorithm === "bfs" ? bfs : dijkstra;
      (selected.events || []).forEach((e) => toast(e, "warn"));
      if (!selected.available) toast(selected.message, "error");
      setResult({ req, dijkstra, bfs, selected });
      setPrev(before);
      setViz({ mode: req.algorithm, idx: 0, playing: false });
    } catch (e) { toast(e.message, "error"); }
  };

  const runEvac = async (body) => {
    try {
      const r = await api.evacuate(body);
      setEvac(r);
      if (body.commit) { await load(); toast("Evacuation executed: shelters updated.", "ok"); }
      else toast(`Plan ready: ${r.summary.assigned} assigned, ${r.summary.unassigned} unassigned.`, "info");
      setViz({ mode: "pq", idx: 0, playing: false });
      setTab("viz");
    } catch (e) { toast(e.message, "error"); }
  };

  const toggleRoad = async (road) => {
    try {
      const r = road.blocked ? await api.unblock(road.id) : await api.block(road.id);
      await load();
      toast(r.message, road.blocked ? "ok" : "warn");
      if (result) {
        await calculate(result.req, result);
        toast(`Route recalculated because Road ${road.id} is ${road.blocked ? "reopened" : "blocked"}.`, "info");
      }
    } catch (e) { toast(e.message, "error"); }
  };

  const simulate = async (body) => {
    try {
      const r = await api.simulate(body);
      setSim(r); setEvac(r.after); await load();
      toast(r.message + " Evacuation plan recalculated.", "warn");
      if (result) calculate(result.req, result);
    } catch (e) { toast(e.message, "error"); }
  };

  const reset = async () => {
    try { await api.reset(); setResult(null); setPrev(null); setEvac(null); setSim(null); await load(); toast("Scenario reset.", "ok"); }
    catch (e) { toast(e.message, "error"); }
  };

  if (!sc) return <div className="boot">{err ? <div className="alert error">{err}<br /><button className="btn" onClick={load}>Retry</button></div> : "Loading command center..."}</div>;

  const st = sc.stats;
  const step = tab === "viz" && viz.mode !== "pq" ? steps[viz.idx] : null;
  const cards = [
    [Users, "Affected", st.affected, ""], [UserCheck, "Evacuated", st.evacuated, "ok"], [UserX, "Remaining", st.remaining, "bad"],
    [Building2, "Shelter Capacity Free", `${st.available_capacity}/${st.total_capacity}`, ""],
    [Construction, "Blocked Roads", `${st.blocked_roads}/${st.total_roads}`, "warn"], [RouteIcon, "Active Routes", st.active_routes, ""],
  ];
  const tabs = [["planner", "Planner"], ["viz", "Visualizer"], ["sim", "Simulation"], ["net", "Network"]];

  return (
    <div className="app">
      <header>
        <div>
          <h1>🛡️ SAFE ROUTE <small>Emergency Evacuation Command Center</small></h1>
          <p className="muted">AI-Assisted Algorithmic Disaster Evacuation Planner · Real-Time Route Optimization · Priority-Based Evacuation</p>
        </div>
        <div className="head-right">
          <span className="status"><Siren size={16} /> EMERGENCY STATUS: ACTIVE</span>
          <button className="btn small" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>{theme === "dark" ? <Sun size={14} /> : <Moon size={14} />}</button>
        </div>
      </header>

      <section className="stats">
        {cards.map(([Icon, label, value, cls]) => (
          <div key={label} className={`stat ${cls}`}><Icon size={22} /><div><div className="num">{value}</div><div className="muted">{label}</div></div></div>
        ))}
      </section>

      <main>
        <div className="mapwrap">
          <MapView sc={sc} onToggleRoad={toggleRoad} highlight={step}
            route={result?.selected?.available ? result.selected.path : null}
            prevRoute={prev?.selected?.available ? prev.selected.path : null}
            evacRoutes={(evac?.plan || []).flatMap((p) => p.assignments.map((a) => a.path))} />
          <div className="legend">🔴 Danger zone · 🔵 Evacuation point · 🟢 Shelter · ⚫ Road · 🚧 Blocked (click a road to block) · 🟡 Active route</div>
        </div>
        <aside>
          <div className="tabs">{tabs.map(([k, l]) => <button key={k} className={tab === k ? "on" : ""} onClick={() => setTab(k)}>{l}</button>)}</div>
          {tab === "planner" && <Planner sc={sc} result={result} prev={prev} onCalculate={calculate} onEvac={runEvac} />}
          {tab === "viz" && <Visualizer sc={sc} viz={viz} setViz={setViz} steps={steps} result={result} evac={evac} onRunEvac={runEvac} />}
          {tab === "sim" && <Simulation sc={sc} sim={sim} onSimulate={simulate} />}
          {tab === "net" && <Network sc={sc} onToggle={toggleRoad} onReset={reset} />}
        </aside>
      </main>

      <div className="toasts">{toasts.map((t) => <div key={t.id} className={`toast ${t.kind}`}>{t.msg}</div>)}</div>
    </div>
  );
}
