// All calls go to the Flask endpoints (see backend/app.py).
const BASE = import.meta.env.VITE_API_URL || "http://127.0.0.1:5000/api";

async function call(path, method = "GET", body) {
  try {
    const res = await fetch(BASE + path, {
      method,
      headers: { "Content-Type": "application/json" },
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Request failed");
    return data;
  } catch (e) {
    if (e instanceof TypeError) throw new Error("Backend unavailable. Start the Flask server (python app.py) on port 5000.");
    throw e;
  }
}

export const api = {
  scenario: () => call("/scenario"),
  route: (algo, body) => call("/" + algo, "POST", body),          // algo = "dijkstra" | "bfs"
  evacuate: (body) => call("/evacuate", "POST", body),
  block: (road_id) => call("/block-road", "POST", { road_id }),
  unblock: (road_id) => call("/unblock-road", "POST", { road_id }),
  simulate: (body) => call("/simulate", "POST", body),
  reset: () => call("/reset", "POST", {}),
};
