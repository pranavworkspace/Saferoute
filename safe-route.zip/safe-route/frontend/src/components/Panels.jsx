import { useState } from "react";
import { Play, Pause, SkipForward, RotateCcw } from "lucide-react";

const PRIO = { Critical: 1, High: 2, Medium: 3, Low: 4 };
const PL = ["", "Critical", "High", "Medium", "Low"];
const Badge = ({ p }) => <span className={`badge p${p}`}>{PL[p]}</span>;
const Chips = ({ items, names, cls = "" }) => (
  <div className="chips">
    {items.length ? items.map((i) => <span key={i} className={`chip ${cls}`}>{names[i] || i}</span>) : <span className="muted">empty</span>}
  </div>
);
const Row = ({ k, v }) => <div className="kv"><span>{k}</span><b>{v}</b></div>;

/* ---------- PLANNER ---------- */
export function Planner({ sc, result, prev, onCalculate, onEvac }) {
  const zones = sc.nodes.filter((n) => n.type === "zone");
  const shelters = sc.nodes.filter((n) => n.type === "shelter");
  const [f, setF] = useState({ start: zones[0]?.id || "", destination: "auto", priority: "Critical", algorithm: "dijkstra" });
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const r = result?.selected;
  const d = result?.dijkstra, b = result?.bfs;
  const yn = (x) => (x.available ? "Yes" : "No");
  return (
    <div className="stack">
      <div className="card">
        <h3>🧭 Evacuation Planner</h3>
        <label>Danger Zone
          <select value={f.start} onChange={set("start")}>{zones.map((z) => <option key={z.id} value={z.id}>{z.name}</option>)}</select>
        </label>
        <label>Shelter
          <select value={f.destination} onChange={set("destination")}>
            <option value="auto">Auto - nearest shelter with capacity</option>
            {shelters.map((s) => <option key={s.id} value={s.id}>{s.name} ({s.capacity - s.occupied} free)</option>)}
          </select>
        </label>
        <div className="two">
          <label>Priority
            <select value={f.priority} onChange={set("priority")}>{Object.keys(PRIO).map((p) => <option key={p}>{p}</option>)}</select>
          </label>
          <label>Algorithm
            <select value={f.algorithm} onChange={set("algorithm")}><option value="dijkstra">Dijkstra</option><option value="bfs">BFS</option></select>
          </label>
        </div>
        <button className="btn primary" onClick={() => onCalculate(f)}>Calculate Evacuation Route</button>
        <div className="two">
          <button className="btn" onClick={() => onEvac({ algorithm: f.algorithm, max_priority: PRIO[f.priority], commit: false })}>Preview Priority Plan</button>
          <button className="btn danger" onClick={() => onEvac({ algorithm: f.algorithm, max_priority: PRIO[f.priority], commit: true })}>Execute Evacuation</button>
        </div>
        <p className="muted">The priority plan pops every group with priority up to the selected level from the priority queue and assigns shelters with free capacity.</p>
      </div>

      {r && (
        <div className="card">
          <h3>📋 Route Result</h3>
          {(r.events || []).map((e, i) => <div key={i} className="alert warn">{e}</div>)}
          {!r.available ? <div className="alert error">{r.message}</div> : (
            <>
              <Row k="Algorithm" v={r.algorithm} />
              <Row k="Starting location" v={r.start_name} />
              <Row k="Destination shelter" v={r.destination_name} />
              <Row k="Priority" v={r.priority} />
              <Row k="Distance / cost" v={`${r.cost} km`} />
              <Row k="Nodes visited" v={r.visited_nodes} />
              <Row k="Path length" v={`${r.path.length} nodes (${r.hops} hops)`} />
              <Row k="Estimated travel time" v={`${r.estimated_time} min`} />
              <Row k="Shelter availability" v={`${r.shelter.available} of ${r.shelter.capacity} free`} />
              <div className="path">{r.path_names.map((n, i) => <span key={i}>{n}</span>)}</div>
            </>
          )}
          {prev?.selected && (
            <div className="alert info">
              <b>Before:</b> {prev.selected.available ? prev.selected.path_names.join(" → ") : "no route"}<br />
              <b>After:</b> {r.available ? r.path_names.join(" → ") : "no route"}
            </div>
          )}
        </div>
      )}

      {d && b && (
        <div className="card">
          <h3>⚖️ BFS vs Dijkstra</h3>
          <table>
            <thead><tr><th></th><th>BFS</th><th>Dijkstra</th></tr></thead>
            <tbody>
              <tr><td>Nodes visited</td><td>{b.visited_nodes}</td><td>{d.visited_nodes}</td></tr>
              <tr><td>Path length (hops)</td><td>{b.hops ?? "-"}</td><td>{d.hops ?? "-"}</td></tr>
              <tr><td>Total cost (km)</td><td>{b.cost ?? "-"}</td><td>{d.cost ?? "-"}</td></tr>
              <tr><td>Execution (ms)</td><td>{b.execution_ms}</td><td>{d.execution_ms}</td></tr>
              <tr><td>Route available</td><td>{yn(b)}</td><td>{yn(d)}</td></tr>
            </tbody>
          </table>
          <p className="muted"><b>BFS</b> suits minimum-hop paths when every road is treated as equal cost (unweighted graph). <b>Dijkstra</b> suits minimum-cost paths when road weights are non-negative. Neither is universally better; each answers a different question.</p>
        </div>
      )}
    </div>
  );
}

/* ---------- ALGORITHM VISUALIZER ---------- */
export function Visualizer({ sc, viz, setViz, steps, result, evac, onRunEvac }) {
  const names = Object.fromEntries(sc.nodes.map((n) => [n.id, n.name]));
  const s = steps[viz.idx];
  const last = viz.idx >= steps.length - 1;
  const go = (p) => setViz({ ...viz, ...p });
  const algo = result?.[viz.mode];
  const planItem = viz.mode === "pq" ? evac?.plan?.[viz.idx] : null;
  return (
    <div className="stack">
      <div className="card">
        <h3>🔬 Algorithm Visualizer</h3>
        <div className="tabs small">
          {[["dijkstra", "Dijkstra"], ["bfs", "BFS"], ["pq", "Priority Queue"]].map(([m, l]) => (
            <button key={m} className={viz.mode === m ? "on" : ""} onClick={() => setViz({ mode: m, idx: 0, playing: false })}>{l}</button>
          ))}
        </div>
        <div className="controls">
          <button className="btn small" disabled={!steps.length} onClick={() => go({ playing: true, idx: last ? 0 : viz.idx })}><Play size={14} /> Start</button>
          <button className="btn small" onClick={() => go({ playing: false })}><Pause size={14} /> Pause</button>
          <button className="btn small" disabled={!steps.length} onClick={() => go({ playing: false, idx: Math.min(viz.idx + 1, steps.length - 1) })}><SkipForward size={14} /> Next Step</button>
          <button className="btn small" onClick={() => go({ playing: false, idx: 0 })}><RotateCcw size={14} /> Reset</button>
        </div>
        {steps.length > 0 && <div className="muted">Step {viz.idx + 1} / {steps.length}</div>}
      </div>

      {!steps.length && (
        <div className="card">
          {viz.mode === "pq"
            ? <><p>Run a priority plan to watch the queue release the most urgent group first.</p><button className="btn primary" onClick={() => onRunEvac({ algorithm: "dijkstra", max_priority: 4, commit: false })}>Run Priority Plan</button></>
            : <p>Calculate a route in the Planner first, then step through the algorithm here.</p>}
        </div>
      )}

      {s && viz.mode === "dijkstra" && (
        <div className="card">
          <Row k="Current node (cheapest in queue)" v={`${names[s.current]} - cost ${s.cost} km`} />
          <h4>Distance updates</h4>
          {s.updates.length ? s.updates.map((u) => <div key={u.node} className="muted">{names[u.node]} → {u.dist} km</div>) : <div className="muted">none</div>}
          <h4>Priority queue (cost, node)</h4>
          <div className="chips">{s.pq.length ? s.pq.map(([c, n]) => <span key={n} className="chip">{names[n]} ({c})</span>) : <span className="muted">empty</span>}</div>
          <h4>Visited nodes ({s.visited.length})</h4>
          <Chips items={s.visited} names={names} cls="done" />
          {last && algo?.available && <><h4>Final path</h4><div className="path">{algo.path_names.map((n, i) => <span key={i}>{n}</span>)}</div></>}
        </div>
      )}

      {s && viz.mode === "bfs" && (
        <div className="card">
          <Row k="Current level" v={s.level} />
          <Row k="Current node" v={names[s.current]} />
          <h4>Queue (FIFO)</h4><Chips items={s.queue} names={names} />
          <h4>Visited nodes ({s.visited.length})</h4><Chips items={s.visited} names={names} cls="done" />
          <h4>Levels discovered</h4>
          {Object.entries(algo?.levels || {}).map(([lv, ns]) => <div key={lv} className="muted"><b>Level {lv}:</b> {ns.map((n) => names[n]).join(", ")}</div>)}
          {last && algo?.available && <><h4>Final path</h4><div className="path">{algo.path_names.map((n, i) => <span key={i}>{n}</span>)}</div></>}
          <p className="muted">BFS treats every road as one hop, so it finds the fewest roads, not the shortest distance.</p>
        </div>
      )}

      {s && viz.mode === "pq" && (
        <div className="card">
          <div className="alert ok"><b>Removed from queue:</b> {s.removed.name} ({names[s.removed.zone]}, {s.removed.size} people) - Priority {s.removed.priority} <Badge p={s.removed.priority} /></div>
          {planItem && (
            <>
              {planItem.assignments.map((a, i) => <div key={i} className="muted">{planItem.zone_name} → {a.shelter_name}: {a.people} people</div>)}
              {planItem.events.map((e, i) => <div key={i} className="alert warn">{e}</div>)}
              {planItem.remaining_unassigned > 0 && <div className="alert error">{planItem.remaining_unassigned} people could not be assigned.</div>}
            </>
          )}
          <h4>Next</h4>
          {s.next ? <div>{s.next.name} - Priority {s.next.priority} <Badge p={s.next.priority} /></div> : <div className="muted">Queue is empty</div>}
          <h4>Queue contents ({s.queue.length})</h4>
          {s.queue.map((q) => <div key={q.id} className="qrow"><Badge p={q.priority} /> {q.name} <span className="muted">({q.size})</span></div>)}
        </div>
      )}
    </div>
  );
}

/* ---------- EMERGENCY SIMULATION ---------- */
export function Simulation({ sc, sim, onSimulate }) {
  const [type, setType] = useState("block_road");
  const roads = sc.roads.filter((r) => !r.blocked);
  const shelters = sc.nodes.filter((n) => n.type === "shelter");
  const [v, setV] = useState({ road_id: "", shelter_id: "", percent: 25, population: 40, capacity: 80 });
  const set = (k) => (e) => setV({ ...v, [k]: e.target.value });
  const run = () => {
    const body = { type };
    if (type === "block_road") body.road_id = v.road_id || roads[0]?.id;
    if (type === "fill_shelter") body.shelter_id = v.shelter_id || shelters[0]?.id;
    if (type === "increase_population") body.percent = Number(v.percent);
    if (type === "new_zone") body.population = Number(v.population);
    if (type === "new_shelter") body.capacity = Number(v.capacity);
    onSimulate(body);
  };
  const route = (p) => (p && p.assignments.length ? p.assignments.map((a) => `${a.path_names.join(" → ")} (${a.people})`).join(" | ") : "No route / no capacity");
  return (
    <div className="stack">
      <div className="card">
        <h3>⚡ Emergency Simulation</h3>
        <label>What-if scenario
          <select value={type} onChange={(e) => setType(e.target.value)}>
            <option value="block_road">Road blocked</option>
            <option value="fill_shelter">Shelter full</option>
            <option value="new_zone">New danger zone</option>
            <option value="increase_population">Increased population</option>
            <option value="new_shelter">New shelter</option>
          </select>
        </label>
        {type === "block_road" && <label>Road<select value={v.road_id} onChange={set("road_id")}>{roads.map((r) => <option key={r.id} value={r.id}>{r.id}: {sc.nodes.find((n) => n.id === r.from).name} - {sc.nodes.find((n) => n.id === r.to).name}</option>)}</select></label>}
        {type === "fill_shelter" && <label>Shelter<select value={v.shelter_id} onChange={set("shelter_id")}>{shelters.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></label>}
        {type === "increase_population" && <label>Increase (%)<input type="number" min="1" value={v.percent} onChange={set("percent")} /></label>}
        {type === "new_zone" && <label>Population<input type="number" min="1" value={v.population} onChange={set("population")} /></label>}
        {type === "new_shelter" && <label>Capacity<input type="number" min="1" value={v.capacity} onChange={set("capacity")} /></label>}
        <button className="btn primary" onClick={run}>Apply &amp; Recalculate Plan</button>
      </div>
      {sim && (
        <div className="card">
          <div className="alert info">{sim.message}</div>
          <Row k="Unassigned BEFORE" v={sim.before.summary.unassigned} />
          <Row k="Unassigned AFTER" v={sim.after.summary.unassigned} />
          {sim.after.plan.map((a) => {
            const b = sim.before.plan.find((x) => x.group.id === a.group.id);
            return (
              <div key={a.group.id} className="ba">
                <b>{a.group.name}</b> <Badge p={a.group.priority} /> <span className="muted">{a.zone_name}</span>
                <div className="muted">Before: {b ? route(b) : "(new group)"}</div>
                <div>After: {route(a)}</div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ---------- NETWORK: shelters + roads ---------- */
export function Network({ sc, onToggle, onReset }) {
  const N = Object.fromEntries(sc.nodes.map((n) => [n.id, n.name]));
  return (
    <div className="stack">
      <div className="card">
        <h3>🏥 Shelter Capacity</h3>
        {sc.nodes.filter((n) => n.type === "shelter").map((s) => {
          const free = s.capacity - s.occupied;
          return (
            <div key={s.id} className="shelter">
              <div className="kv"><b>{s.name}</b><span>{free === 0 ? <span className="badge p1">FULL</span> : `${free} free`} · {s.occupied}/{s.capacity}</span></div>
              <div className="bar"><i style={{ width: `${(s.occupied / s.capacity) * 100}%` }} className={free === 0 ? "full" : ""} /></div>
            </div>
          );
        })}
      </div>
      <div className="card">
        <h3>🚧 Dynamic Road Network</h3>
        <div className="roads">
          {sc.roads.map((r) => (
            <div key={r.id} className="kv">
              <span className={r.blocked ? "blocked" : ""}>{r.id}: {N[r.from]} - {N[r.to]} ({r.distance} km)</span>
              <button className="btn small" onClick={() => onToggle(r)}>{r.blocked ? "Unblock" : "Block"}</button>
            </div>
          ))}
        </div>
        <button className="btn" onClick={onReset}>Reset Scenario</button>
      </div>
    </div>
  );
}
