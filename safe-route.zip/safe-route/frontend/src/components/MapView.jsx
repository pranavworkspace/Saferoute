import { MapContainer, TileLayer, Polyline, Circle, CircleMarker, Marker, Popup } from "react-leaflet";
import L from "leaflet";

const pin = (cls, emoji) =>
  L.divIcon({ className: "", html: `<div class="pin ${cls}">${emoji}</div>`, iconSize: [32, 32], iconAnchor: [16, 16], popupAnchor: [0, -14] });
const PL = ["", "Critical", "High", "Medium", "Low"];

export default function MapView({ sc, route, evacRoutes, prevRoute, highlight, onToggleRoad }) {
  const N = Object.fromEntries(sc.nodes.map((n) => [n.id, n]));
  const pos = (id) => [N[id].lat, N[id].lng];
  const seen = new Set(highlight?.visited || []);
  const state = (id) => (id === highlight?.current ? " current" : seen.has(id) ? " visited" : "");
  const mid = (r) => [(N[r.from].lat + N[r.to].lat) / 2, (N[r.from].lng + N[r.to].lng) / 2];

  const RoadPopup = ({ r }) => (
    <Popup>
      <b>Road {r.id}</b><br />{N[r.from].name} - {N[r.to].name}<br />
      {r.distance} km - {r.time} min - {r.blocked ? "BLOCKED" : "Open"}<br />
      <button className="btn small" onClick={() => onToggleRoad(r)}>{r.blocked ? "Unblock road" : "Block road"}</button>
    </Popup>
  );

  return (
    <MapContainer center={sc.center} zoom={13} className="map" scrollWheelZoom>
      <TileLayer attribution="&copy; OpenStreetMap contributors" url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
      {sc.roads.map((r) => (
        <Polyline key={r.id} positions={[pos(r.from), pos(r.to)]}
          pathOptions={r.blocked ? { color: "#ef4444", weight: 4, dashArray: "8 8" } : { color: "#64748b", weight: 3 }}>
          <RoadPopup r={r} />
        </Polyline>
      ))}
      {sc.roads.filter((r) => r.blocked).map((r) => (
        <Marker key={"b" + r.id} position={mid(r)} icon={pin("block", "🚧")}><RoadPopup r={r} /></Marker>
      ))}
      {prevRoute?.length > 1 && <Polyline positions={prevRoute.map(pos)} pathOptions={{ color: "#a78bfa", weight: 4, dashArray: "3 9" }} />}
      {evacRoutes.map((p, i) => <Polyline key={"e" + i} positions={p.map(pos)} pathOptions={{ color: "#f59e0b", weight: 4, opacity: 0.8 }} />)}
      {route?.length > 1 && <Polyline positions={route.map(pos)} pathOptions={{ color: "#facc15", weight: 7, className: "route-line" }} />}

      {sc.nodes.map((n) => {
        if (n.type === "junction")
          return (
            <CircleMarker key={n.id} center={pos(n.id)} radius={highlight && state(n.id) ? 9 : 6}
              pathOptions={{ color: state(n.id) ? "#facc15" : "#0f172a", fillColor: state(n.id).includes("current") ? "#facc15" : "#cbd5e1", fillOpacity: 1 }}>
              <Popup><b>{n.name}</b><br />Road junction</Popup>
            </CircleMarker>
          );
        if (n.type === "shelter")
          return (
            <Marker key={n.id} position={pos(n.id)} icon={pin("shelter" + state(n.id), "🏥")}>
              <Popup><b>{n.name}</b><br />Capacity: {n.capacity}<br />Occupied: {n.occupied}<br />Available: {n.capacity - n.occupied}</Popup>
            </Marker>
          );
        const groups = sc.groups.filter((g) => g.zone === n.id);
        const left = groups.filter((g) => g.size > g.evacuated);
        const pop = left.reduce((s, g) => s + g.size - g.evacuated, 0);
        const top = left.length ? PL[Math.min(...left.map((g) => g.priority))] : "Cleared";
        return [
          <Circle key={n.id + "c"} center={pos(n.id)} radius={350 + pop * 5}
            pathOptions={{ color: "#ef4444", fillColor: "#ef4444", fillOpacity: pop ? 0.25 : 0.05 }} />,
          <Marker key={n.id} position={pos(n.id)} icon={pin("zone" + state(n.id), "📍")}>
            <Popup><b>{n.name}</b><br />Affected population: {pop}<br />Priority: {top}</Popup>
          </Marker>,
        ];
      })}
    </MapContainer>
  );
}
