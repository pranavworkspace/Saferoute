"""Road network as a weighted, undirected graph stored as an ADJACENCY LIST."""
import json, math, time


def haversine(a, b):
    """Great-circle distance in km between two nodes (used as road weight)."""
    la1, lo1, la2, lo2 = map(math.radians, (a["lat"], a["lng"], b["lat"], b["lng"]))
    h = math.sin((la2 - la1) / 2) ** 2 + math.cos(la1) * math.cos(la2) * math.sin((lo2 - lo1) / 2) ** 2
    return 2 * 6371.0 * math.asin(math.sqrt(h))


def reconstruct(prev, start, goal):
    """Walk the 'previous node' links backwards from goal to start."""
    path, cost, minutes = [goal], 0.0, 0.0
    while path[-1] != start:
        parent, dist, mins, _ = prev[path[-1]]
        cost += dist
        minutes += mins
        path.append(parent)
    return path[::-1], round(cost, 2), round(minutes, 1)


def build_result(name, start, found, prev, visited, steps, t0):
    """Common response shape shared by BFS and Dijkstra."""
    res = {"algorithm": name, "start": start, "visited_nodes": len(visited), "visited_order": visited,
           "steps": steps, "available": found is not None,
           "execution_ms": round((time.perf_counter() - t0) * 1000, 3)}
    if found:
        path, cost, minutes = reconstruct(prev, start, found)
        res.update(destination=found, path=path, cost=cost, estimated_time=minutes, hops=len(path) - 1)
    else:
        res.update(destination=None, path=[], cost=None, estimated_time=None, hops=None)
    return res


class Graph:
    def __init__(self, scenario):
        self.center = scenario["center"]
        self.nodes = {n["id"]: dict(n) for n in scenario["nodes"]}
        self.groups = [dict(g, evacuated=0) for g in scenario["groups"]]
        self.roads = []
        for a, b in scenario["roads"]:
            self.add_road(a, b)

    @classmethod
    def load(cls, path):
        with open(path, encoding="utf-8") as f:
            return cls(json.load(f))

    def add_road(self, a, b):
        dist = round(haversine(self.nodes[a], self.nodes[b]), 2)
        self.roads.append({"id": f"R{len(self.roads) + 1}", "from": a, "to": b, "distance": dist,
                           "time": max(1, round(dist * 2.4)), "blocked": False})

    def add_node(self, node, links=2):
        """Insert a node and connect it to its nearest neighbours."""
        near = sorted(self.nodes.values(), key=lambda n: haversine(node, n))[:links]
        self.nodes[node["id"]] = node
        for other in near:
            self.add_road(node["id"], other["id"])

    def adjacency(self):
        """adj[u] = [(v, distance, time, road_id)]. BLOCKED roads are left out of the graph."""
        adj = {n: [] for n in self.nodes}
        for r in self.roads:
            if r["blocked"]:
                continue
            adj[r["from"]].append((r["to"], r["distance"], r["time"], r["id"]))
            adj[r["to"]].append((r["from"], r["distance"], r["time"], r["id"]))
        return adj

    def shelter_ids(self):
        return [i for i, n in self.nodes.items() if n["type"] == "shelter"]

    def occupancy(self):
        return {s: self.nodes[s]["occupied"] for s in self.shelter_ids()}
