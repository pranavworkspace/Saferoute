"""Evacuation logic: route finding with shelter capacity + priority-based assignment."""
from algorithms.bfs import bfs
from algorithms.dijkstra import dijkstra
from algorithms.priority_queue import EvacuationQueue, PRIORITY_LABELS

ALGORITHMS = {"bfs": bfs, "dijkstra": dijkstra}


def find_route(graph, algorithm, start, destination, occupancy):
    if algorithm not in ALGORITHMS:
        raise ValueError("Invalid algorithm. Choose 'dijkstra' or 'bfs'.")
    shelters = graph.shelter_ids()
    auto = destination in (None, "auto")
    if not auto and destination not in shelters:
        raise ValueError(f"Invalid destination '{destination}'.")
    name = lambda i: graph.nodes[i]["name"]
    run, adj = ALGORITHMS[algorithm], graph.adjacency()
    open_shelters = {s for s in shelters if graph.nodes[s]["capacity"] - occupancy[s] > 0}
    events = []
    res = run(adj, start, set(shelters) if auto else {destination})
    if res["available"] and res["destination"] not in open_shelters:
        # Capacity constraint: a FULL shelter can never receive more people.
        events.append(f"⚠ {name(res['destination'])} is FULL → searching for alternative shelter...")
        if not open_shelters:
            raise ValueError("All shelters are full. No capacity remains for evacuation.")
        res = run(adj, start, open_shelters)
        if res["available"]:
            events.append(f"✔ Alternative selected: {name(res['destination'])}")
    res["events"] = events
    res["start_name"] = name(start)
    if res["available"]:
        d = res["destination"]
        res["destination_name"] = name(d)
        res["path_names"] = [name(p) for p in res["path"]]
        cap = graph.nodes[d]["capacity"]
        res["shelter"] = {"capacity": cap, "occupied": occupancy[d], "available": cap - occupancy[d]}
    else:
        res["message"] = (f"No evacuation route is currently available from {name(start)}. "
                          "All connecting roads are blocked.")
    return res


def _brief(g):
    return {"id": g["id"], "name": g["name"], "zone": g["zone"], "size": g["remaining"],
            "priority": g["priority"], "label": PRIORITY_LABELS[g["priority"]]}


def plan_evacuation(graph, algorithm, max_priority=4, commit=False):
    """Pop groups from the priority queue (most urgent first) and assign each to shelters with room."""
    occ = graph.occupancy()
    queue = EvacuationQueue()
    for g in graph.groups:
        left = g["size"] - g["evacuated"]
        if left > 0 and g["priority"] <= max_priority:
            queue.push(g["priority"], dict(g, remaining=left))
    plan, queue_steps, assigned_total, unassigned_total = [], [], 0, 0
    while len(queue):
        g = queue.pop()
        queue_steps.append({"removed": _brief(g), "next": _brief(queue.peek()) if queue.peek() else None,
                            "queue": [_brief(i) for i in queue.snapshot()]})
        left, assignments, events = g["remaining"], [], []
        while left > 0:
            try:
                r = find_route(graph, algorithm, g["zone"], "auto", occ)
            except ValueError as e:
                events.append(str(e))
                break
            events += r["events"]
            if not r["available"]:
                events.append(r["message"])
                break
            sid = r["destination"]
            people = min(left, graph.nodes[sid]["capacity"] - occ[sid])
            occ[sid] += people
            left -= people
            assignments.append({"shelter": sid, "shelter_name": r["destination_name"], "people": people,
                                "path": r["path"], "path_names": r["path_names"], "cost": r["cost"],
                                "time": r["estimated_time"], "visited_nodes": r["visited_nodes"]})
        done = g["remaining"] - left
        assigned_total += done
        unassigned_total += left
        plan.append({"group": _brief(g), "zone_name": graph.nodes[g["zone"]]["name"], "assignments": assignments,
                     "remaining_unassigned": left, "events": events})
        if commit:
            for real in graph.groups:
                if real["id"] == g["id"]:
                    real["evacuated"] += done
    if commit:
        for s, o in occ.items():
            graph.nodes[s]["occupied"] = o
    return {"algorithm": algorithm, "plan": plan, "queue_steps": queue_steps,
            "summary": {"assigned": assigned_total, "unassigned": unassigned_total}}
