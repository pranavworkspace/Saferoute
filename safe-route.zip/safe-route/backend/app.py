"""SAFE ROUTE - Flask API. Routes stay thin; all DAA logic lives in algorithms/ and evacuation.py."""
import os
from flask import Flask, jsonify, request
from flask_cors import CORS
from graph.graph import Graph
from evacuation import ALGORITHMS, find_route, plan_evacuation
from algorithms.priority_queue import PRIORITY_LABELS

app = Flask(__name__)
CORS(app)
DATA = os.path.join(os.path.dirname(__file__), "data", "scenario.json")
G = Graph.load(DATA)
ACTIVE = {"routes": 0}
PRIORITIES = {"critical": 1, "high": 2, "medium": 3, "low": 4}


def body():
    return request.get_json(silent=True) or {}


def parse_priority(value, default=4):
    if value in (None, ""):
        return default
    if isinstance(value, str) and value.lower() in PRIORITIES:
        return PRIORITIES[value.lower()]
    if isinstance(value, int) and 1 <= value <= 4:
        return value
    raise ValueError("Invalid priority. Use Critical, High, Medium or Low.")


def get_road(road_id):
    for r in G.roads:
        if r["id"] == road_id:
            return r
    raise ValueError(f"Invalid road '{road_id}'.")


def statistics():
    total = sum(g["size"] for g in G.groups)
    evac = sum(g["evacuated"] for g in G.groups)
    sh = [G.nodes[s] for s in G.shelter_ids()]
    return {"affected": total, "evacuated": evac, "remaining": total - evac, "shelters": len(sh),
            "total_capacity": sum(s["capacity"] for s in sh),
            "available_capacity": sum(s["capacity"] - s["occupied"] for s in sh),
            "blocked_roads": sum(r["blocked"] for r in G.roads), "total_roads": len(G.roads),
            "active_routes": ACTIVE["routes"]}


@app.errorhandler(ValueError)
def bad_request(e):
    return jsonify({"error": str(e)}), 400


@app.get("/api/scenario")
def scenario():
    return jsonify({"center": G.center, "nodes": list(G.nodes.values()), "roads": G.roads,
                    "groups": G.groups, "stats": statistics(), "priorities": PRIORITY_LABELS})


@app.get("/api/shelters")
def shelters():
    return jsonify([dict(G.nodes[s], available=G.nodes[s]["capacity"] - G.nodes[s]["occupied"])
                    for s in G.shelter_ids()])


@app.get("/api/statistics")
def stats():
    return jsonify(statistics())


def route_endpoint(algorithm):
    b = body()
    start = b.get("start")
    if not start:
        raise ValueError("Empty input: please choose a danger zone.")
    if start not in G.nodes:
        raise ValueError(f"Invalid location '{start}'.")
    priority = parse_priority(b.get("priority"))
    res = find_route(G, algorithm, start, b.get("destination") or "auto", G.occupancy())
    res["priority"] = PRIORITY_LABELS[priority]
    return jsonify(res)


@app.post("/api/bfs")
def bfs_route():
    return route_endpoint("bfs")


@app.post("/api/dijkstra")
def dijkstra_route():
    return route_endpoint("dijkstra")


@app.post("/api/evacuate")
def evacuate():
    b = body()
    algorithm = str(b.get("algorithm", "dijkstra")).lower()
    if algorithm not in ALGORITHMS:
        raise ValueError("Invalid algorithm. Choose 'dijkstra' or 'bfs'.")
    commit = bool(b.get("commit", False))
    result = plan_evacuation(G, algorithm, parse_priority(b.get("max_priority"), 4), commit)
    if commit:
        ACTIVE["routes"] = sum(len(p["assignments"]) for p in result["plan"])
    result["stats"] = statistics()
    return jsonify(result)


def set_blocked(blocked):
    road = get_road(body().get("road_id"))
    road["blocked"] = blocked
    names = f"{G.nodes[road['from']]['name']} - {G.nodes[road['to']]['name']}"
    verb = "blocked" if blocked else "reopened"
    return jsonify({"message": f"Road {road['id']} ({names}) is {verb}. Routes recalculated.",
                    "road": road, "stats": statistics()})


@app.post("/api/block-road")
def block_road():
    return set_blocked(True)


@app.post("/api/unblock-road")
def unblock_road():
    return set_blocked(False)


@app.post("/api/simulate")
def simulate():
    """What-if engine: plan BEFORE, change the scenario, plan AFTER."""
    b = body()
    kind = b.get("type")
    before = plan_evacuation(G, "dijkstra", 4, False)
    n = len(G.nodes)
    if kind == "block_road":
        road = get_road(b.get("road_id"))
        road["blocked"] = True
        msg = f"Road {road['id']} blocked."
    elif kind == "fill_shelter":
        node = G.nodes.get(b.get("shelter_id"))
        if not node or node["type"] != "shelter":
            raise ValueError("Invalid shelter.")
        node["occupied"] = node["capacity"]
        msg = f"{node['name']} is now FULL."
    elif kind == "increase_population":
        pct = float(b.get("percent", 25))
        if pct <= 0:
            raise ValueError("Population increase must be positive.")
        for g in G.groups:
            g["size"] = round(g["size"] * (1 + pct / 100))
        msg = f"Population increased by {pct:g}%."
    elif kind == "new_zone":
        zid, people = f"Z{n}", int(b.get("population", 40))
        G.add_node({"id": zid, "name": f"New Zone {n}", "type": "zone",
                    "lat": 17.415 + 0.003 * (n % 5), "lng": 78.525})
        G.groups.append({"id": f"G{len(G.groups) + 1}", "zone": zid, "name": "New residents",
                         "size": people, "priority": 2, "evacuated": 0})
        msg = f"New danger zone appeared ({people} people)."
    elif kind == "new_shelter":
        cap = int(b.get("capacity", 80))
        G.add_node({"id": f"S{n}", "name": f"New Shelter {n}", "type": "shelter",
                    "lat": 17.355 + 0.003 * (n % 5), "lng": 78.455, "capacity": cap, "occupied": 0})
        msg = f"New shelter opened (capacity {cap})."
    else:
        raise ValueError("Invalid simulation type.")
    after = plan_evacuation(G, "dijkstra", 4, False)
    return jsonify({"message": msg, "before": before, "after": after, "stats": statistics()})


@app.post("/api/reset")
def reset():
    global G
    G = Graph.load(DATA)
    ACTIVE["routes"] = 0
    return jsonify({"message": "Scenario reset.", "stats": statistics()})


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
