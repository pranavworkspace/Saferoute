"""BFS: explores level by level. Every road counts as ONE hop (unweighted), so it finds the MINIMUM-HOP path."""
import time
from collections import deque
from graph.graph import build_result


def bfs(adj, start, goals):
    t0 = time.perf_counter()
    level = {start: 0}
    prev = {}
    queue = deque([start])               # FIFO queue
    visited, steps, found = [], [], None
    while queue:
        u = queue.popleft()
        visited.append(u)
        if u in goals:
            found = u
        else:
            for v, w, t, rid in adj[u]:
                if v not in level:       # first discovery = fewest hops
                    level[v] = level[u] + 1
                    prev[v] = (u, w, t, rid)
                    queue.append(v)
        steps.append({"current": u, "level": level[u], "queue": list(queue), "visited": list(visited)})
        if found:
            break
    res = build_result("BFS", start, found, prev, visited, steps, t0)
    levels = {}
    for node, lv in level.items():
        levels.setdefault(str(lv), []).append(node)
    res["levels"] = levels
    return res
