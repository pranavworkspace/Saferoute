"""Priority queue for emergency triage: lowest number = most urgent (1 Critical ... 4 Low)."""
import heapq, itertools

PRIORITY_LABELS = {1: "Critical", 2: "High", 3: "Medium", 4: "Low"}


class EvacuationQueue:
    def __init__(self):
        self._heap = []
        self._order = itertools.count()   # tie-breaker: equal priorities leave in arrival order

    def push(self, priority, item):
        heapq.heappush(self._heap, (priority, next(self._order), item))   # O(log n)

    def pop(self):
        return heapq.heappop(self._heap)[2]                               # O(log n)

    def peek(self):
        return self._heap[0][2] if self._heap else None

    def snapshot(self):
        return [item for _, _, item in sorted(self._heap)]

    def __len__(self):
        return len(self._heap)
