"""Dijkstra: minimum-COST path for NON-NEGATIVE road weights, driven by a priority queue (heapq)."""
import heapq, time
from graph.graph import build_result


def dijkstra(adj, start, goals):
    t0 = time.perf_counter()
    dist = {start: 0.0}          # tentative distances
    prev = {}                    # previous node on the best known path
    done, visited, steps = set(), [], []
    heap = [(0.0, start)]        # priority queue ordered by tentative distance
    found = None
    while heap:
        d, u = heapq.heappop(heap)          # cheapest unexplored node
        if u in done:                       # stale entry (lazy deletion)
            continue
        done.add(u)
        visited.append(u)
        updates = []
        if u in goals:                      # first goal popped is the cheapest one
            found = u
        else:
            for v, w, t, rid in adj[u]:     # relax every outgoing edge
                nd = d + w
                if v not in done and nd < dist.get(v, float("inf")):
                    dist[v] = nd
                    prev[v] = (u, w, t, rid)
                    heapq.heappush(heap, (nd, v))
                    updates.append({"node": v, "dist": round(nd, 2)})
        steps.append({"current": u, "cost": round(d, 2), "updates": updates, "visited": list(visited),
                      "pq": [[round(x, 2), n] for x, n in sorted(heap) if n not in done]})
        if found:
            break
    return build_result("Dijkstra", start, found, prev, visited, steps, t0)
