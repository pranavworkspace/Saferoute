# 🛡️ SAFE ROUTE - Disaster Evacuation Planner

**Emergency Evacuation Command Center** - an interactive simulation that plans evacuations from danger zones to shelters and *visually explains* how BFS, Dijkstra and a Priority Queue make each decision.

> The intelligence comes from classic DAA algorithms. **No AI/ML model is used.**

## Problem
During a disaster, roads get blocked, shelters fill up and some people (ICU patients) must leave before others. Planners need routes that adapt instantly.

## Solution
A road network is modelled as a weighted graph. Dijkstra finds minimum-cost routes, BFS finds minimum-hop routes, a priority queue decides who leaves first, and shelter capacity is a hard constraint. Blocking a road removes the edge from the graph and routes are recalculated.

## Features
Live Leaflet map (OpenStreetMap, no API key) · statistic cards · route planner · step-by-step algorithm visualizer (Start / Pause / Next / Reset) · priority-queue panel · capacity-aware shelter assignment with automatic alternative shelters · block/unblock roads (click a road) · BEFORE/AFTER what-if simulation · BFS vs Dijkstra comparison · dark/light theme · friendly error messages.

## Stack
React + Vite + Leaflet/React-Leaflet + CSS · Python Flask + Flask-CORS · `heapq`, `collections.deque`. In-memory data (`backend/data/scenario.json`), no database.

## Structure
```
safe-route/
├── backend/  app.py  evacuation.py  requirements.txt
│   ├── algorithms/ bfs.py dijkstra.py priority_queue.py
│   ├── graph/graph.py        (adjacency list)
│   └── data/scenario.json    (15 nodes, 24 roads, 5 zones, 4 shelters, 10 groups)
└── frontend/ src/ App.jsx main.jsx index.css  components/ (MapView, Panels)  services/api.js
```
Flask routes only validate input and call the algorithm modules.

## Algorithms
- **Graph**: `adj[u] = [(v, distance, time, road_id)]`. Blocked roads are skipped when the list is built → *dynamic graph modification*.
- **BFS**: FIFO queue, explores level by level, treats each road as 1 hop → minimum-hop path, reachability. O(V+E).
- **Dijkstra**: `heapq` min-heap of (tentative cost, node); pop cheapest, relax neighbours, store `prev`, rebuild the path. Needs non-negative weights. O((V+E) log V). Stops at the cheapest goal shelter.
- **Priority Queue**: groups keyed by priority 1 Critical → 4 Low (ties leave in arrival order). Push/pop O(log n).
- **Shelter assignment**: groups leave the queue most-urgent first; each is routed to the nearest shelter with free space; if that shelter is full the search repeats among shelters with capacity; leftovers go to the next shelter.
- **Neither BFS nor Dijkstra is "better"**: BFS answers "fewest roads", Dijkstra answers "lowest cost".

## Run (Windows / VS Code)
Backend:
```
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Frontend (new terminal):
```
cd frontend
npm install
npm run dev
```
Open **http://localhost:5173**. API runs on http://127.0.0.1:5000.

## API
| Method | Endpoint | Body |
|---|---|---|
| GET | /api/scenario, /api/shelters, /api/statistics | |
| POST | /api/dijkstra, /api/bfs | `{start, destination ("auto" or shelter id), priority}` |
| POST | /api/evacuate | `{algorithm, max_priority (1-4), commit}` |
| POST | /api/block-road, /api/unblock-road | `{road_id}` |
| POST | /api/simulate | `{type: block_road\|fill_shelter\|new_zone\|increase_population\|new_shelter, ...}` |
| POST | /api/reset | |

Example: `POST /api/dijkstra {"start":"ZA","destination":"SA"}` → `{"algorithm":"Dijkstra","start":"ZA","destination":"SA","path":["ZA","J1","SA"],"cost":4.94,"visited_nodes":6,"estimated_time":12,...}`

## Demo (3-5 min)
1. Dashboard: show zones, shelters, stat cards. 2. Planner: Zone A, Critical, Dijkstra → Calculate (animated route). 3. Preview Priority Plan → Visualizer shows the queue releasing Critical first. 4. Click a road on the route → Block → route recalculates (purple dashed = before). 5. Simulation → "Shelter full" → alternative shelters appear. 6. Choose BFS, Calculate, read the comparison table. 7. Execute Evacuation → final statistics.

## Future improvements
Real OpenStreetMap road graphs, live traffic weights, A*, multi-vehicle capacity, persistence.
